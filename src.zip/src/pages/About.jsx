import React from "react";
import FooterCompact from "../components/FooterCompact";

export default function AboutPage() {
  return (
    <div className="bg-white text-gray-800 font-sans">

      {/* SECTION 1: Hero 배너 */}
      <section className="relative w-full h-[400px] bg-[#00A89C] text-white flex flex-col justify-center items-center text-center px-4">
        <p className="text-sm tracking-widest mb-2">회사 소개</p>
        <h1 className="text-4xl md:text-6xl font-bold mb-4">ABOUT CURAEL</h1>
        <p className="text-base md:text-lg max-w-2xl">
          자연에서 시작된 건강, 큐라엘은 당신의 삶을 위한 과학적 해답을 만듭니다.
        </p>
      </section>

      {/* SECTION 2: 산마을 스타일 인트로 */}
      <section className="relative w-full max-w-screen-2xl mx-auto overflow-hidden rounded-xl my-16">
        <img
          src="/images/about-nature.png"
          alt="회사 철학 이미지"
          className="w-full h-[520px] object-cover object-center"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center text-center text-white px-6">
          <p className="text-sm tracking-widest mb-2">COMPANY INTRODUCTION</p>
          <h2 className="text-3xl md:text-4xl font-bold leading-tight mb-10">
            자연의 선물에<br className="hidden md:block" />
            정성만을 더하였습니다
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 w-full max-w-6xl text-sm">
            <ValueBox icon="🕒" title="2023년 설립" text="큐라엘은 자연 유래 건강기능식품 시장에서 신뢰를 쌓아온 전문 브랜드입니다." />
            <ValueBox icon="🍃" title="자연의 조화" text="과학적 접근을 통해 자연이 가진 힘을 온전히 전달하는 제품을 만듭니다." />
            <ValueBox icon="🤝" title="정직하고 안전한" text="정직한 정보와 투명한 제조 과정을 통해 고객 신뢰를 쌓습니다." />
          </div>
        </div>
      </section>

      {/* SECTION 3: 회사 개요 정보 */}
      <section className="bg-gray-50 py-20 px-6 lg:px-24">
        <div className="max-w-screen-xl mx-auto">
          <h2 className="text-2xl font-bold mb-10 text-center">회사 개요</h2>
          <dl className="grid grid-cols-1 md:grid-cols-2 gap-y-8 gap-x-16 text-sm text-gray-700">
            <Info label="회사명" value="(주)큐라엘" />
            <Info label="설립일자" value="2023년 6월" />
            <Info label="대표이사" value="김훈하" />
            <Info label="소재지" value="서울특별시 강남구 ○○로 123" />
            <Info label="사업분야" value="건강기능식품 제조 및 유통" />
            <Info label="주요제품" value="베지셀, 커큐진, 베라베라진 외 다수" />
          </dl>
        </div>
      </section>

      {/* SECTION 4: 브랜드 철학 */}
      <section className="py-24 bg-white text-center px-6 lg:px-24">
        <div className="max-w-screen-md mx-auto">
          <h2 className="text-2xl font-bold mb-4">큐라엘의 철학</h2>
          <p className="text-base text-gray-600 leading-relaxed">
            큐라엘은 자연에서 출발하여 과학으로 완성됩니다.  
            믿을 수 있는 원료와 정직한 제조 과정을 통해  
            삶에 긍정적인 변화를 주는 건강한 제품을 연구합니다.
          </p>
        </div>
      </section>

      {/* SECTION 5: CTA */}
      <section className="text-center py-20 bg-gray-50 px-6">
        <h2 className="text-xl font-semibold mb-6">큐라엘의 건강 솔루션을 만나보세요</h2>
        <a
          href="/products"
          className="inline-block bg-[#00A89C] text-white px-6 py-3 rounded-full text-sm hover:bg-[#009088] transition"
        >
          제품 보기
        </a>
      </section>

      {/* Footer */}
      <FooterCompact />
    </div>
  );
}

// 컴포넌트들
function Info({ label, value }) {
  return (
    <div>
      <dt className="font-semibold text-gray-500 mb-1">{label}</dt>
      <dd className="text-gray-800">{value}</dd>
    </div>
  );
}

function ValueBox({ icon, title, text }) {
  return (
    <div className="flex flex-col items-center px-4">
      <div className="text-4xl mb-3">{icon}</div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-sm text-center">{text}</p>
    </div>
  );
}
