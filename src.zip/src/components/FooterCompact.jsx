import { FaYoutube, FaInstagram } from "react-icons/fa";
import { SiKakaotalk } from "react-icons/si";

export default function FooterCompact() {
  return (
    <footer className="bg-[#f4f4f4] text-gray-800 text-[15px] md:text-[15px] py-10 md:py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-10">
        {/* Left: Logo */}
        <div className="flex-shrink-0 flex items-center pr-4 md:pr-10">
          <img src="/images/Signature Horizontal.png" alt="CURAEL Logo" className="w-36 md:w-40" />
        </div>

        {/* Middle: Company Info */}
        <div className="flex-grow flex flex-col justify-center">
          <p className="font-semibold">
            (주)큐라엘 &nbsp;&nbsp; 서울특별시 노원구 동일로 1622 &nbsp;&nbsp; 대표: 김훈하
          </p>
          <p>
            전화번호: 02-935-9843 &nbsp;&nbsp; 이메일: yulbangrc@gmail.com
          </p>
          <p className="mt-2 text-gray-500">© 2025 CURAEL. All rights reserved.</p>
        </div>

        {/* Right: Store Buttons + SNS */}
        <div className="flex flex-col items-start md:items-end justify-center gap-3">
          {/* Store Buttons */}
          <div className="flex flex-col gap-2">
            <a
              href="https://smartstore.naver.com/vegicel_yulbang"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-transparent border border-gray-300 rounded-full px-6 py-3 text-sm text-gray-500 hover:bg-gray-100 transition"
            >
              베지셀 스토어
            </a>
            <a
              href="https://smartstore.naver.com/jayeonha"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-transparent border border-gray-300 rounded-full px-6 py-3 text-sm text-gray-500 hover:bg-gray-100 transition"
            >
              자연하 스토어
            </a>
          </div>

          {/* SNS Icons */}
          <div className="flex gap-4 mt-4 text-xl">
            <a
              href="https://www.youtube.com/@yulbangsangdamso"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#cd201f] hover:text-red-600"
              title="YouTube"
            >
              <FaYoutube size={28} />
            </a>
            <a
              href="https://pf.kakao.com/_Apnys"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#fae100] hover:text-yellow-400"
              title="Kakao"
            >
              <SiKakaotalk size={28} />
            </a>
            <a
              href="https://instagram.com/hoonha_yulbang?igsh=NGhkaW5rcDV3a2V1"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#e1306c] hover:text-pink-500"
              title="Instagram"
            >
              <FaInstagram size={28} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
