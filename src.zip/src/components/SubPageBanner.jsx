import React from "react";
import { useLocation, Link } from "react-router-dom";
import subPageData from "../data/subPageData";

export default function SubPageBanner({ page }) {
  const location = useLocation();
  const { title, engTitle, subText, bgImage, tabs = [] } = subPageData[page];

  return (
    <section className="relative w-full h-[460px] md:h-[520px] overflow-hidden font-sans">
      {/* 배경 이미지 */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
        style={{ backgroundImage: `url('${bgImage}')` }}
      />

      {/* 어두운 오버레이 */}
      <div className="absolute inset-0 bg-black opacity-50 z-10" />

      {/* 콘텐츠 */}
      <div className="relative z-20 flex flex-col justify-start items-center h-full pt-60 text-white text-center px-4 gap-y-4">
        <p className="text-sm md:text-base tracking-widest uppercase mb-1 font-light">
          {engTitle}
        </p>
        <h1 className="text-3xl md:text-5xl font-bold mb-2">{title}</h1>
        <p className="text-2xl md:text-medium font-light opacity-90 mb-6">
          {subText}
        </p>
      </div>
    </section>
  );
}
