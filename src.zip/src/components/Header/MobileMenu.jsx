import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export default function MobileMenu({ navItems, onClose }) {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key="mobile-menu"
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ duration: 0.4, ease: "easeInOut" }}
        className="fixed top-[64px] inset-x-0 bottom-0 z-50 bg-black/60 overflow-y-auto"
      >
        {/* 메뉴 영역 */}
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ duration: 0.4, ease: "easeInOut" }}
          className="bg-white w-full h-full py-4 px-0"
        >
          <ul className="divide-y divide-gray-200">
            {navItems.map((item, idx) => (
              <li key={idx}>
                <button
                  className={`w-full flex justify-between items-center py-3 px-5 font-Medium text-base ${
                    openIndex === idx ? "bg-green-600 text-white" : "bg-white text-gray-800"
                  }`}
                  onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                >
                  {item.label}
                  <span>{openIndex === idx ? "▲" : "▼"}</span>
                </button>

                <AnimatePresence>
                  {openIndex === idx && (
                    <motion.ul
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden bg-orange-50 text-gray-800 text-[15px]"
                    >
                      {item.submenu.map((sub, subIdx) => (
                        <li key={subIdx} className="py-3 px-6 border-b">
                          <a href="#" onClick={onClose} className="block w-full">
                            {sub}
                          </a>
                        </li>
                      ))}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </li>
            ))}
          </ul>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}