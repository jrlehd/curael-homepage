import React, { useState, useEffect } from "react";
import NavItem from "./NavItem";
import MobileMenu from "./MobileMenu";
import { Sling as Hamburger } from "hamburger-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    handleScroll();
    handleResize();
    window.addEventListener("scroll", handleScroll);
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const navItems = [
    { label: "회사소개", submenu: ["회사소개", "인사말", "비전"] },
    { label: "제품소개", submenu: ["전체제품", "베지셀", "자연하", "서적"] },
    { label: "열방상담소", submenu: ["열방상담소", "위치안내"] },
    { label: "연구/개발", submenu: ["연구/개발"] },
    { label: "문의안내", submenu: ["문의안내"] },
  ];

  const headerClass = `fixed top-0 left-0 w-full z-50 border-b transition-all duration-300
    ${scrolled || mobileMenuOpen
      ? "bg-white text-black border-gray-200 shadow-sm"
      : "bg-transparent text-white border-white/30"}`;

  return (
    <header className={headerClass}>
      {/* 상단 메뉴 바 */}
      <div
        className="w-full px-4 md:px-8 py-5 md:py-9 min-h-[64px] md:min-h-[80px] flex items-center justify-between relative"
      >
        {/* 로고 */}
        <a href="/" className="ml-4 md:ml-12">
          <img
            src={
              scrolled || mobileMenuOpen
                ? "/images/SymbolMark.png"
                : "/images/SymbolMark_dark.png"
            }
            alt="Logo"
            className="h-6 md:h-12 transition-opacity duration-300"
          />
        </a>

        {/* 데스크탑 메뉴 */}
        <motion.nav
          className="hidden md:flex absolute left-1/2 -translate-x-1/2 gap-x-[5rem]"
          animate={{ gap: scrolled || mobileMenuOpen ? "6rem" : "5rem" }}
          transition={{ duration: 0.4 }}
        >
          {navItems.map((item, index) => (
            <NavItem
              key={index}
              label={item.label}
              submenu={item.submenu}
              textColor={scrolled || mobileMenuOpen ? "text-black" : "text-white"}
              fontWeight="font-medium"
              textSize="text-[17px]"
            />
          ))}
        </motion.nav>

        {/* 햄버거 메뉴 (모바일 전용) */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 z-[999] md:hidden">
          <Hamburger
            toggled={mobileMenuOpen}
            toggle={(val) => setMobileMenuOpen(val)}
            size={32}
            color={scrolled || mobileMenuOpen ? "#000" : "#fff"}
            rounded
            duration={0.4}
          />
        </div>
      </div>

      {/* 모바일 메뉴 */}
      <AnimatePresence mode="wait">
        {mobileMenuOpen && isMobile && (
          <MobileMenu
            key="mobile-menu"
            navItems={navItems}
            onClose={() => setMobileMenuOpen(false)}
          />
        )}
      </AnimatePresence>
    </header>
  );
}